#include <linux/fs.h>
#include <linux/init.h>
#include <linux/module.h>
#include <linux/uaccess.h>

#define FILENAME "/custom/metro/system/system_config.ini"

static char buf[] = "5555\n";
static char buf1[10] = {0};

int hello_init(void)
{
	struct file *filp;
	loff_t pos;

	printk("hello enter\n");

	filp = filp_open(FILENAME, O_RDWR | O_CREAT, 0644);
	if (IS_ERR(filp)) {
		printk("create file error\n");
		return -1;
	}

	pos = 0;
	kernel_write(filp, buf, sizeof(buf), &pos);

	pos = 0;
	kernel_read(filp, buf1, sizeof(buf1) - 1, &pos);
	printk("read: %s", buf1);

	filp_close(filp, NULL);

	return 0;
}
void hello_exit(void)
{
	printk("hello exit\n");
}

module_init(hello_init);
module_exit(hello_exit);

MODULE_LICENSE("GPL");
