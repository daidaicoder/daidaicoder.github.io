#include <linux/init.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/dcache.h>
#include <linux/fs.h>
#include <linux/err.h>
#include <linux/string.h>
#include <linux/errno.h>
#include <asm/fcntl.h>
#include <asm/processor.h>
#include <asm/uaccess.h>
#include <linux/thread_info.h>

int __init hello_init(void)
{
    unsigned char buf1[12]="hello world.";
    unsigned char buf2[12]="kernel file.";
    char buf3[10] = {0};

    struct file *fp;
    //mm_segment_t fs;
    loff_t pos;

    printk("hello enter\n");
    fp = filp_open("/custom/metro/system/system_config.ini", O_RDWR | O_CREAT, 0644);
    if (IS_ERR(fp)) {
        printk("create file error\n");
        return -1;
    }
    //fs = force_uaccess_begin();

   // current_thread_info()->addr_limit = 0;
    //fs = get_fs();
    //set_fs(KERNEL_DS);

    pos = fp->f_pos;
    __kernel_write(fp, buf1, sizeof(buf1), &pos);
    fp->f_pos = pos;

    pos = fp->f_pos;
    __kernel_write(fp, buf2, sizeof(buf2), &pos);
    fp->f_pos = pos;

    printk(KERN_INFO "kernel_daizelai File content:\n%s\n", buf2);


    // 不添加下面四行，是可以写的。
    // memset(buf, 0, sizeof(buf3));
    // pos = fp->f_pos;
    // kernel_read(fp, buf3, sizeof(buf3)-1, &pos);
    // printk(KERN_INFO "kernel_daizelai File content:\n%s\n", buf3);



    //set_fs(fs);
    //force_uaccess_end(fs);

    filp_close(fp, NULL);
    return 0;
}

void __exit hello_exit(void)
{
    printk("hello exit\n");
}

module_init(hello_init);
module_exit(hello_exit);

MODULE_LICENSE("GPL");
