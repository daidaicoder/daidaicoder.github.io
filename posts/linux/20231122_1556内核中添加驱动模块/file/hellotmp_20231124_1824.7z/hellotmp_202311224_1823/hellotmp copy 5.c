#include <linux/init.h>
#include <linux/module.h>
#include <linux/sched.h>
#include <linux/dcache.h>
#include <linux/fs.h>
#include <linux/err.h>
#include <linux/string.h>
#include <linux/errno.h>
#include <asm/fcntl.h>
#include <asm/processor.h>
#include <asm/uaccess.h>
#include <linux/thread_info.h>

int __init hello_init(void)
{
    struct file *fp = NULL;
    char buf[256];
    loff_t pos = 0;

    if(filep == NULL) {
        filep = filp_open("/custom/metro/system/system_config.ini", O_RDWR | O_CREAT, 0644);
    }

    if (IS_ERR(fp)) {
        printk("create file error\n");
        return -1;
    }

    // sprintf(buf,"%s\n", "This is test message!");

    memset(buf, 0, sizeof(buf));
    kernel_read(filep, buf, sizeof(buf), &pos);
    // printk("Read buf -> %s\n", buf);

    filp_close(fp, NULL);
    return 0;
}

void __exit hello_exit(void)
{
    printk("hello exit\n");
}

module_init(hello_init);
module_exit(hello_exit);

MODULE_LICENSE("GPL");
