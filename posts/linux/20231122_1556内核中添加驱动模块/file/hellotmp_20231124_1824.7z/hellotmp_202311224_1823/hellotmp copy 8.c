#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
#include <linux/string.h>
#include <linux/slab.h>
#include <linux/types.h>
#include <linux/moduleparam.h>

// insmod your_module.ko config_file_path=/path/to/your/config_file.ini， 在没有指定模块参数时将使用这个默认路径。

#define DEFAULT_CONFIG_FILE_PATH "/custom/system_config.ini"
static char *config_file_path = DEFAULT_CONFIG_FILE_PATH;
module_param(config_file_path, charp, 0000);

//static char codeBuf[1024];

struct ConfigData {
    unsigned int *code;  // 使用指针来表示变长数组
    size_t code_size;    // 记录数组的大小
};

// 函数声明
void print_array(const unsigned int *array, size_t size);
int contains_value(const unsigned int *array, size_t size, unsigned int value);
int parse_config(const char *buffer, struct ConfigData *config);
int read_file(const char *file_path, char *buffer, size_t buffer_size);
void read_config_file(const char *file_path, char *buffer, size_t buffer_size);
void handle_config_file(const char *file_content, struct ConfigData *my_config);

// 读取文件的辅助函数
int read_file(const char *file_path, char *buffer, size_t buffer_size) {
    struct file *fp;
    mm_segment_t fs;
    loff_t pos = 0;
    int err;

    fp = filp_open(file_path, O_RDWR | O_CREAT, 0644);
    if (IS_ERR(fp)) {
        printk("Error opening config file: %ld\n", PTR_ERR(fp));
        return PTR_ERR(fp);
    }

    fs = get_fs();
    set_fs(KERNEL_DS);

    err = vfs_read(fp, buffer, buffer_size, &pos);
    if (err < 0) {
        printk("read file error: %d\n", err);
        filp_close(fp, NULL);
        set_fs(fs);
        return err;
    }

    filp_close(fp, NULL);
    set_fs(fs);

    return 0;
}

void read_config_file(const char *file_path, char *buffer, size_t buffer_size) {
    int err = read_file(file_path, buffer, buffer_size);
    if (err < 0) {
        // 处理读取文件错误...
        printk("Failed to read config file: %d\n", err);
    } else if (strlen(buffer) == 0) {
        // 文件内容为空
        printk("Config file is empty.\n");
    } else {
        // 处理配置文件内容
        struct ConfigData my_config = {
            .code = NULL
        };
        handle_config_file(buffer, &my_config);
    }
}

int __init hello_init(void)
{
    struct ConfigData my_config = {
        .code = NULL
    };
    u8 reg_e5 = 0xb1;

    printk("hello enter\n");

    // 读取配置文件
    read_config_file(config_file_path, codeBuf, sizeof(codeBuf));

    // 处理配置文件内容
    handle_config_file(codeBuf, &my_config);

    if (my_config.code != NULL) {
        kfree(my_config.code);
    }

    return 0;
}

// 打印数组的辅助函数
void print_array(const unsigned int *array, size_t size) {
    size_t i;

    printk("Array contents: [");
    for (i = 0; i < size; ++i) {
        printk("%x", array[i]);
        if (i < size - 1) {
            printk(", ");
        }
    }
    printk("]\n");
    // Array contents: [b1, b2]
}

// 判断数组中是否包含特定值
int contains_value(const unsigned int *array, size_t size, unsigned int value) {
    size_t i;

    // 先打印数组
    print_array(array, size);

    for (i = 0; i < size; ++i) {
        if (array[i] == value) {
            return 1;  // 包含特定值
        }
    }
    return 0;  // 不包含特定值
}

// 处理配置文件内容的函数
void handle_config_file(const char *file_content, struct ConfigData *my_config) {
    // 解析配置文件
    if (parse_config(file_content, my_config) == 0) {
        if (my_config->code != NULL && my_config->code_size > 0) {
            // 有有效的 code 数据
            printk("Parsed code array with %zu elements.\n", my_config->code_size);
            print_array(my_config->code, my_config->code_size);

            u8 reg_e5 = 0xb1;
            if (contains_value(my_config->code, my_config->code_size, reg_e5)) {
                printk("The array contains reg_e5.----------------------%x\n", reg_e5);
            } else {
                printk("The array does not contain reg_e5.+++++++++++++++%x\n", reg_e5);
            }
        } else {
            printk("No valid code data found in the config file.\n");
        }
    } else {
        printk("parse_config failed\n");
    }
}


// 解析配置文件的函数
int parse_config(const char *buffer, struct ConfigData *config) {
    const char *line, *key, *value;
    char *context = (char *)buffer;
    char *delim = "\n";

    printk("parse_config start\n");

    line = buffer;
    while ((line = strsep(&context, delim)) != NULL) {
        if (line[0] == '\0') {
            // 空行，跳过
            continue;
        }

        key = strsep((char **)&line, "=");
        value = strsep((char **)&line, "=");

        if (key != NULL && value != NULL) {
            if (strcmp(key, "code") == 0) {
                const char *token = strsep((char **)&value, ",");
                size_t i = 0;

                while (token != NULL) {
                    config->code = krealloc(config->code, (i + 1) * sizeof(unsigned int), GFP_KERNEL);
                    if (!config->code) {
                        printk("Failed to reallocate memory for code array.\n");
                        return -ENOMEM;
                    }

                    if (strstr(token, "0x") != token) {
                        char hex_token[10];
                        snprintf(hex_token, sizeof(hex_token), "0x%s", token);
                        if (sscanf(hex_token, "0x%x", &config->code[i]) != 1) {
                            printk("Failed to parse code value. parse_config failed\n");
                            return -EINVAL;
                        }
                    } else {
                        if (sscanf(token, "0x%x", &config->code[i]) != 1) {
                            printk("Failed to parse code value. parse_config failed\n");
                            return -EINVAL;
                        }
                    }

                    i++;
                    token = strsep((char **)&value, ",");
                }

                config->code_size = i;
            }
        }
    }
    printk("parse_config end\n");

    return 0;
}


void __exit hello_exit(void)
{
    printk("hello exit\n");
}

module_init(hello_init);
module_exit(hello_exit);

MODULE_AUTHOR("Zelai Dai <daizelai@gbcom.com.cn>");
MODULE_DESCRIPTION("read system ini main module");
MODULE_LICENSE("GPL");
