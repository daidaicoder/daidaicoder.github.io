#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
// 解析数据需要的头文件
#include <linux/string.h>

#define CONFIG_FILE_PATH "/custom/system_config.ini"

//static char buf[] = "你好";
static char buf1[1024];

// 假设这是从文件中读取的数据
//  const char *fileData = "[HexValues]\nValue1 = 0xABCD\nValue2 = 0x1234\n";
// void processIniData(const char *data) {
//     char section[50];
//     char key[50];
//     unsigned int hexValue;

//     // 使用sscanf手动解析读取的数据
//     while (sscanf(data, "[%49[^]]", section) == 1) {
//         data = strchr(data, '\n');  // 移动到下一行
//         if (data == NULL) {
//             break;
//         }
//         data++;  // 跳过换行符

//         while (sscanf(data, " %49[^=] = 0x%X", key, &hexValue) == 2) {
//             printk("[%s] %s = 0x%X\n", section, key, hexValue);
//             data = strchr(data, '\n');  // 移动到下一行
//             if (data == NULL) {
//                 break;
//             }
//             data++;  // 跳过换行符
//         }
//     }
// }


// [system]
// mac=aa:bb:cc:dd:00
//
// [code]
// code=0xb1,0xb2,0xb3
//
struct ConfigData {
    unsigned char mac[6];
    unsigned int code[3];
}

// 解析配置文件的函数
int parse_config(const char *buffer, struct ConfigData *config)
{
    const char *line, *key, *value;
    char *context;

    // strtok_r 用于分割字符串
    line = strtok_r(buffer, "\n", &context);
    while (line != NULL) {
        // 使用 strtok_r 分割键值对
        key = strtok_r((char *)line, "=", &context);
        value = strtok_r(NULL, "=", &context);

        if (key != NULL && value != NULL) {
            // 检查键是否为 "mac"
            if (strcmp(key, "mac") == 0) {
                // 使用 sscanf 解析 MAC 地址
                sscanf(value, "%hhx:%hhx:%hhx:%hhx:%hhx:%hhx",
                       &config->mac[0], &config->mac[1], &config->mac[2],
                       &config->mac[3], &config->mac[4], &config->mac[5]);
            }
            // 检查键是否为 "code"
            else if (strcmp(key, "code") == 0) {
                // 使用 sscanf 解析代码
                sscanf(value, "0x%x,0x%x,0x%x",
                       &config->code[0], &config->code[1], &config->code[2]);
            }
        }

        // 获取下一行
        line = strtok_r(NULL, "\n", &context);
    }

    return 0;
}

int __init hello_init(void)
{
    struct file *fp;
    mm_segment_t fs;
    loff_t pos = 0;
    int err;

    printk("hello enter\n");
    fp = filp_open(CONFIG_FILE_PATH, O_RDWR | O_CREAT, 0644);
    if (IS_ERR(fp)) {
        printk("create file error\n");
        // return -1;
        return PTR_ERR(fp);
    }

    fs = get_fs();
    set_fs(KERNEL_DS);

    err = vfs_read(fp, buf1, sizeof(buf1), &pos);
    if (err < 0) {
        printk("read file error: %d\n", err);
        filp_close(fp, NULL);
        set_fs(fs);
        return err;
    }

    //pos = 0;
    //vfs_write(fp, buf, sizeof(buf), &pos);
    // pos = 0;
    // vfs_read(fp, buf1, sizeof(buf1), &pos);
    printk("read: %s\n", buf1);

    filp_close(fp, NULL);
    set_fs(fs);


    // // 使用strtok分割字符串
    // char *token = strtok(buf1, ",");
    // while (token != NULL) {
    //     unsigned long hexValue;
    //     if (kstrtoul(token, 16, &hexValue) == 0) {
    //         u8 reg_e5 = hexValue;
    //         if (reg_e5 != 0xb0 && reg_e5 != 0x01) {
    //             pr_info("Found valid value: 0x%02X\n", reg_e5);
    //             // 在这里可以进行相应的处理
    //             printk("++++++++++++++++++++++++++++read: %02X\n", reg_e5);
    //         }
    //     }
    //     token = strtok(NULL, ",");
    // }

    struct ConfigData myConfig;

    if (parse_config(buf1, &myConfig) == 0) {
        // // 在这里使用 myConfig.mac 和 myConfig.code 进行判断
        // if (myConfig.code[0] != 0xb0 && myConfig.code[0] != 0x01) {
        //     // 执行相应的操作
        // }
        u8 reg_e5 = 0;

        if (reg_e5 == myConfig.code[0] && reg_e5 == myConfig.code[1] && reg_e5 == myConfig.code[2]) {
            // 执行相应的操作
        }
    } else {
        // 解析失败，处理错误
    }








    return 0;
}
void __exit hello_exit(void)
{
    printk("hello exit\n");
}

module_init(hello_init);
module_exit(hello_exit);

MODULE_LICENSE("GPL");
