#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
// 解析数据需要的头文件
#include <linux/string.h>
#include <linux/slab.h>

#define CONFIG_FILE_PATH "/custom/metro/system/system_config.ini"

//static char buf[] = "你好";
static char buf1[1024];

// [system]
// mac=aa:bb:cc:dd:00
//
// [code]
// code=0xb1,0xb2,0xb3
//
struct ConfigData {
    unsigned char mac[6];
    // unsigned int code[3];
    unsigned int *code;  // 使用指针来表示变长数组
    size_t code_size;    // 记录数组的大小
};

// 函数声明
int parse_config(const char *buffer, struct ConfigData *config);


int __init hello_init(void)
{
    struct file *fp;
    mm_segment_t fs;
    loff_t pos = 0;
    int err;

    struct ConfigData myConfig;
    // u8 reg_e5 = 0;

    printk("hello enter\n");
    fp = filp_open(CONFIG_FILE_PATH, O_RDWR | O_CREAT, 0644);
    if (IS_ERR(fp)) {
        printk("create file error\n");
        // return -1;
        return PTR_ERR(fp);
    }

    fs = get_fs();
    set_fs(KERNEL_DS);

    err = vfs_read(fp, buf1, sizeof(buf1), &pos);
    if (err < 0) {
        printk("read file error: %d\n", err);
        filp_close(fp, NULL);
        set_fs(fs);
        return err;
    }

    //pos = 0;
    //vfs_write(fp, buf, sizeof(buf), &pos);
    // pos = 0;
    // vfs_read(fp, buf1, sizeof(buf1), &pos);
    printk("++++++++++++++++++++++++++++++read: %s\n", buf1);



    if (parse_config(buf1, &myConfig) == 0) {
        printk("parse_config succeeded\n");
    }

    // printk("Before parse_config\n");
    // if (parse_config(buf1, &myConfig) == 0) {
    //     printk("parse_config succeeded\n");
    //     printk("read: %x\n", myConfig.code[0]);
    //     if (reg_e5 == myConfig.code[0] && reg_e5 == myConfig.code[1] && reg_e5 == myConfig.code[2]) {
    //         // 执行相应的操作
    //         // 执行相应的操作
    //         printk("Operation succeeded\n");
    //     }
    // } else {
    //     // 解析失败，处理错误
    //     printk("parse_config failed\n");
    // }

    filp_close(fp, NULL);
    set_fs(fs);





    // if (parse_config(buf1, &myConfig) == 0) {
    //     // Check if reg_e5 is equal to each value in the code array
    //     for (size_t i = 0; i < myConfig.code_size; ++i) {
    //         if (reg_e5 == myConfig.code[i]) {
    //             // Perform the corresponding operation
    //             break;  // Exit the loop early if a match is found
    //         }
    //     }
    // } else {
    //     // Handle parsing failure
    // }

    // // 在释放内存前检查是否为 NULL
    // if (myConfig.code != NULL) {
    //     kfree(myConfig.code);
    // }

    return 0;
}

// 解析配置文件的函数
int parse_config(const char *buffer, struct ConfigData *config)
{
    const char *line, *key, *value;
    char *context = (char *)buffer;  // 初始化为 buffer
    char *delim = "\n";
    //size_t i = 0;
    // 在函数一开始初始化 code 为 NULL
    //config->code = NULL;

    printk("parse_config aaaaa\n");




    // 函数原型
    // char *strsep(char **stringp, const char *delim);
    // stringp 带分割字符串(注意这里是二级指针，&取地址)    delim分割符

    line = buffer;
    // strtok_r 用于分割字符串
    //line = strtok_r(buffer, "\n", &context);


    while ((line = strsep(&context, delim)) != NULL) {
        printk("parse_config cccc\n");

        if (line[0] == '\0') {
            continue;  // 空行，跳过
        }




        // 使用 strtok_r 分割键值对
        key = strsep((char **)&line, "=");
        printk("parse_config ddddd\n");
        value = strsep((char **)&line, "=");
        printk("parse_config eeee\n");

        // if (key != NULL && value != NULL) {
        //     // 检查键是否为 "mac"
        //     if (strcmp(key, "mac") == 0) {
        //         // 使用 sscanf 解析 MAC 地址
        //         sscanf(value, "%hhx:%hhx:%hhx:%hhx:%hhx:%hhx",
        //                &config->mac[0], &config->mac[1], &config->mac[2],
        //                &config->mac[3], &config->mac[4], &config->mac[5]);
        //     }
        //     // 检查键是否为 "code"
        //     else if (strcmp(key, "code") == 0) {
        //         // 解析 code，动态分配内存
        //         const char *token = strsep((char **)&value, ",");
        //         while (token != NULL) {
        //             config->code = krealloc(config->code, (i + 1) * sizeof(unsigned int), GFP_KERNEL);
        //             sscanf(token, "0x%x", &config->code[i++]);
        //             token = strsep((char **)&value, ",");
        //         }
        //         config->code_size = i;
        //     }
        // }

        // 获取下一行
        //line = strtok_r(NULL, "\n", &context);
        context = NULL;
    }
    printk("parse_config fffff\n");

    return 0;
}

void __exit hello_exit(void)
{
    printk("hello exit\n");
}

module_init(hello_init);
module_exit(hello_exit);

MODULE_LICENSE("GPL");
