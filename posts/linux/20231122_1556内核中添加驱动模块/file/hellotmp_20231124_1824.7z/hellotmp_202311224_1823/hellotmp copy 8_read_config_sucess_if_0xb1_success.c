#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/fs.h>
#include <linux/uaccess.h>
// 解析数据需要的头文件
#include <linux/string.h>
#include <linux/slab.h>
// 自定义contains_value函数的时候导入的
#include <linux/types.h>

#define CONFIG_FILE_PATH "/custom/metro/system/system_config.ini"

//static char buf[] = "你好";
static char buf1[1024];

// msm8953_64:/custom/metro/system # cat system_config.ini
// [system]
// self_mac=11:aa:bb:cc:dd
//
// [screen]
// GbcomCode1 = 0xb1
// GbcomCode2 = 0xb5
// GbcomCode3 = 0x31
// [code]
// code=0xb1,0xb2
//
struct ConfigData {
    unsigned char mac[6];
    // unsigned int code[3];
    unsigned int *code;  // 使用指针来表示变长数组
    size_t code_size;    // 记录数组的大小
};

// 函数声明
int parse_config(const char *buffer, struct ConfigData *config);

// 打印数组的辅助函数
void print_array(const unsigned int *array, size_t size) {
    size_t i;

    printk("Array contents: [");
    for (i = 0; i < size; ++i) {
        printk("%x", array[i]);
        if (i < size - 1) {
            printk(", ");
        }
    }
    printk("]\n");
    // Array contents: [b1, b2]
}

// 判断数组中是否包含特定值
int contains_value(const unsigned int *array, size_t size, unsigned int value) {
    size_t i;

    // 先打印数组
    print_array(array, size);

    for (i = 0; i < size; ++i) {
        if (array[i] == value) {
            return 1;  // 包含特定值
        }
    }
    return 0;  // 不包含特定值
}

int __init hello_init(void)
{
    struct file *fp;
    mm_segment_t fs;
    loff_t pos = 0;
    int err;

    //struct ConfigData myConfig;
    struct ConfigData myConfig = {
        .code = NULL
    };
    // u8 reg_e5 = 0; 和 u8 reg_e5 = 0xb1; 都是合法的语句，没有语法错误。
    // 在第一种情况下，u8 reg_e5 = 0; 将 reg_e5 初始化为 0。
    // 在第二种情况下，u8 reg_e5 = 0xb1; 将 reg_e5 初始化为十六进制值 0xb1，即十进制值 177。
    u8 reg_e5 = 0xb1;

    printk("hello enter\n");
    fp = filp_open(CONFIG_FILE_PATH, O_RDWR | O_CREAT, 0644);
    if (IS_ERR(fp)) {
        printk("create file error\n");
        // return -1;
        return PTR_ERR(fp);
    }

    fs = get_fs();
    set_fs(KERNEL_DS);

    err = vfs_read(fp, buf1, sizeof(buf1), &pos);
    if (err < 0) {
        printk("read file error: %d\n", err);
        filp_close(fp, NULL);
        set_fs(fs);
        return err;
    }

    //pos = 0;
    //vfs_write(fp, buf, sizeof(buf), &pos);
    // pos = 0;
    // vfs_read(fp, buf1, sizeof(buf1), &pos);
    printk("++++++++++++++++++++++++++++++read: %s\n", buf1);



    //if (parse_config(buf1, &myConfig) == 0) {
    //    printk("parse_config succeeded\n");
    //}

    printk("Before parse_config\n");
    if (parse_config(buf1, &myConfig) == 0) {
        printk("read1: %x\n", myConfig.code[0]);
        printk("read2: %x\n", myConfig.code[1]);

        if (contains_value(myConfig.code, myConfig.code_size, reg_e5)) {
            // 执行包含 reg_e5 的操作
            // The array contains reg_e5.----------------------b1
            printk("The array contains reg_e5.----------------------%x\n", reg_e5);
        } else {
            // 执行不包含 reg_e5 的操作
            printk("The array does not contain reg_e5.+++++++++++++++%x\n", reg_e5);
        }
    } else {
        // 解析失败，处理错误
        printk("parse_config failed\n");
    }

    filp_close(fp, NULL);
    set_fs(fs);

    // if (parse_config(buf1, &myConfig) == 0) {
    //     // Check if reg_e5 is equal to each value in the code array
    //     for (size_t i = 0; i < myConfig.code_size; ++i) {
    //         if (reg_e5 == myConfig.code[i]) {
    //             // Perform the corresponding operation
    //             break;  // Exit the loop early if a match is found
    //         }
    //     }
    // } else {
    //     // Handle parsing failure
    // }

    // // 在释放内存前检查是否为 NULL，也可以移动到__exit函数中执行。
    if (myConfig.code != NULL) {
        kfree(myConfig.code);
    }

    return 0;
}

// 解析配置文件的函数
int parse_config(const char *buffer, struct ConfigData *config)
{
    const char *line, *key, *value;
    char *context = (char *)buffer;  // 初始化为 buffer
    char *delim = "\n";

    // 在函数一开始初始化 code 为 NULL
    //config->code = NULL;
    printk("parse_config start\n");

    // 函数原型
    // char *strsep(char **stringp, const char *delim);
    // stringp 带分割字符串(注意这里是二级指针，&取地址)    delim分割符
    line = buffer;
    while ((line = strsep(&context, delim)) != NULL) {
        printk("parse_config cccc\n");

        if (line[0] == '\0') {
            // 空行，跳过
            continue;
        }

        // 使用 strtok_r 分割键值对
        // key第一次打印为：[system]，value为(null)，key第二次打印：self_mac，value为：11:aa:bb:cc:dd
        // key第三次打印为[screen]，value为(null)，第四次解析key为：GbcomCode1，value为：0xb1
        // 第五次解析key为：GbcomCode2，value为：0xb5
        // 第六次解析key为：GbcomCode3，value为：0x31
        // 第七次key为：[code]，value为：(null)
        // 第八次key为：code，value为：0xb1,0xb2
        key = strsep((char **)&line, "=");
        printk("parse_config ddddd =======key: %s\n", key);

        value = strsep((char **)&line, "=");
        printk("parse_config eeee ======value: %s\n", value);

        if (key != NULL && value != NULL) {
            printk("parse_config ffffffff\n");
            // 检查键是否为 "mac"
            if (strcmp(key, "mac") == 0) {
                printk("parse_config ggggg\n");
                // 使用 sscanf 解析 MAC 地址
                sscanf(value, "%hhx:%hhx:%hhx:%hhx:%hhx:%hhx",
                       &config->mac[0], &config->mac[1], &config->mac[2],
                       &config->mac[3], &config->mac[4], &config->mac[5]);
            }
            // 检查键是否为 "code"
            else if (strcmp(key, "code") == 0) {
                // 解析 code，动态分配内存
                const char *token = strsep((char **)&value, ",");
                size_t i = 0;
                printk("parse_config hhhhhhhhh\n");
                while (token != NULL) {
                    // 如果数组容量不足，进行扩展
                    config->code = krealloc(config->code, (i + 1) * sizeof(unsigned int), GFP_KERNEL);
                    if (!config->code) {
                        printk("Failed to reallocate memory for code array.\n");
                        return -ENOMEM;
                    }
                    sscanf(token, "0x%x", &config->code[i]);
                    // sscanf(token, "0x%x", &config->code[i++]);
                    printk("parse_config jjjjjjjjjjjjjjjjjjj ------------Parsed code[%zu]: %x\n", i, config->code[i]);
                    i++;
                    token = strsep((char **)&value, ",");
                }
                config->code_size = i;
            }
        }

        printk("parse_config kkkk\n");
    }
    printk("parse_config mmmmmmm\n");

    return 0;
}

void __exit hello_exit(void)
{
    printk("hello exit\n");
}

module_init(hello_init);
module_exit(hello_exit);

MODULE_LICENSE("GPL");
