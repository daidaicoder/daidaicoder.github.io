#include <linux/fs.h>
#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/uaccess.h>
#include "hellotmp.h"

// 本文编译Ko后没有读出来数据。
#define FILE_PATH "/custom/metro/system/system_config.ini"

static struct file *file;
//static DEFINE_RWLOCK(file_lock);

static int __init kernel_read_init(void) {
    mm_segment_t old_fs;
    loff_t pos = 0;
    char buffer[1024];

    // 改变内核数据段的选择符，防止用户空间地址空间越界
    old_fs = get_fs();
    set_fs(KERNEL_DS);

    // 打开文件
    file = filp_open(FILE_PATH, O_RDONLY, 0);
    if (IS_ERR(file)) {
        printk(KERN_ERR "Failed to open file\n");
        return PTR_ERR(file);
    }

    // 获取读取者锁
    //read_lock(&file_lock);

    // 读取文件内容
    memset(buffer, 0, sizeof(buffer));
    vfs_read(file, buffer, sizeof(buffer) - 1, &pos);

    // 打印读取的文件内容
    printk(KERN_INFO "File content:\n%s\n", buffer);

    // 释放读取者锁
    //read_unlock(&file_lock);

    // 恢复内核数据段的选择符
    set_fs(old_fs);

    return 0;
}

static void __exit kernel_read_exit(void) {
    // 关闭文件
    filp_close(file, NULL);
    printk(KERN_INFO "Kernel module unloaded\n");
}

module_init(kernel_read_init);
module_exit(kernel_read_exit);

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Your Name");
MODULE_DESCRIPTION("Kernel module to read a file with locking");
